import tweepy

def main():
    api = tweepy.API(auth)

    public_tweets = api.home_timeline()
    for tweet in public_tweets:
        print({
                'text': tweet.text,
                'loc': tweet.geo,
              })

