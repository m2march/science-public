import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

np.random.seed(115)
vuelos = np.random.randint(3000, 7000, 7)
vuelos_s = [500, 20000]

plt.figure()
plt.box(False)
plt.xticks([])
plt.yticks([])
plt.hlines(0, 300, 22000, color='black')
plt.scatter(vuelos, np.repeat(0, len(vuelos)), color='blue')
plt.scatter(vuelos_s, np.repeat(0, len(vuelos_s)), color='red')
plt.xlim(300, 22000)
plt.ylim(-1, 1)
vs = []
avs = np.concatenate([vuelos, vuelos_s])
for v in sorted(avs):
    if len(vs) == 0 or (v - vs[-1] > 400):
        plt.text(v, 0.3, str(v), rotation=45)
    vs.append(v)
plt.savefig('vuelos.png')

m = np.median(avs)
plt.vlines(m, 0, 0.5, color='green')
plt.vlines(m * 3, 0, 0.5, color='purple')
plt.vlines(m / 5, 0, 0.5, color='purple')
plt.savefig('vuelos2.png')
