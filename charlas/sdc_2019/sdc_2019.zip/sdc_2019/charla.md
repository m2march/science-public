---
title: Cómo trabaja un egresado de la carrera
author: Martin (March) Miguel
---

# Objetivos

* Charlar qué cosas se pueden hacer con la carrera
* Charlar cuál es el perfil de formación

# El mensaje 

La computación es una herramienta multi-uso que va más alla de estar frente a
la compu y saber muchas cosas ténicas.

Es una herramienta para resolver problemas de toda índole.

#
## Nota

Mucho de lo dicho acá va a estar teñido por mi experiencia personal.

#
## Encuesta

¿Eligiendo carrera, alguna carrera, computación?
¿Programar?

#
### Bio

* 2007: Quiero hacer jueguitos, elijo Exactas
* CBC: Curso Java
* Desarollo de apps para BlackBerry
* Ay2, Cs. de la Computación
* Despegar.com
* Pasantía Google (NY)
* MateMarote, Licenciado

#
* Avenida.com
* Doctorado: "Modelos de cognicion musical y patrones en el
  tiempo"
* JTP, Cs. de la Computación


# ¿Por qué aprender computación no es lo mismo que programación? 

#
## Ejemplo 

<video src="code-demo/video-c.mp4" style="width: 90%" controls/>

#
## Programación

* Lenguaje de programación
* Traducir al lenguaje

#
## Computación

* Programación
* Análisis de problemas
* Técnicas de resolución de problemas: abstraer y modularizar
* ...

#
<pre style='color:#000000;background:#ffffff;'>var s1 <span style='color:#808030; '>=</span> createSine<span style='color:#808030; '>(</span><span style='color:#008c00; '>441</span><span style='color:#808030; '>)</span><span style='color:#800080; '>;</span>
var s2 <span style='color:#808030; '>=</span> createSine<span style='color:#808030; '>(</span><span style='color:#008c00; '>641</span><span style='color:#808030; '>)</span><span style='color:#800080; '>;</span>

<span style='color:#800000; font-weight:bold; '>void</span> <span style='color:#400000; '>main</span><span style='color:#808030; '>(</span><span style='color:#808030; '>)</span> <span style='color:#800080; '>{</span>
  <span style='color:#800000; font-weight:bold; '>while</span> <span style='color:#808030; '>(</span>True<span style='color:#808030; '>)</span> <span style='color:#800080; '>{</span>
    <span style='color:#800000; font-weight:bold; '>if</span> <span style='color:#808030; '>(</span>getMouseX<span style='color:#808030; '>(</span><span style='color:#808030; '>)</span> <span style='color:#808030; '>&lt;</span> <span style='color:#008c00; '>100</span><span style='color:#808030; '>)</span> <span style='color:#800080; '>{</span>
        playSound<span style='color:#808030; '>(</span>s1<span style='color:#808030; '>)</span><span style='color:#800080; '>;</span>
    <span style='color:#800080; '>}</span> <span style='color:#800000; font-weight:bold; '>else</span> <span style='color:#800000; font-weight:bold; '>if</span> <span style='color:#808030; '>(</span>getMouseX<span style='color:#808030; '>(</span><span style='color:#808030; '>)</span> <span style='color:#808030; '>></span> <span style='color:#008c00; '>200</span><span style='color:#808030; '>)</span> <span style='color:#800080; '>{</span>
        playSound<span style='color:#808030; '>(</span>s2<span style='color:#808030; '>)</span><span style='color:#800080; '>;</span>
    <span style='color:#800080; '>}</span>
    sleep<span style='color:#808030; '>(</span><span style='color:#008c00; '>1000</span><span style='color:#808030; '>)</span><span style='color:#800080; '>;</span>
  <span style='color:#800080; '>}</span>
<span style='color:#800080; '>}</span>
</pre>
<!--Created using ToHtml.com on 2019-09-09 04:38:11 UTC -->

#
## Computación

* De bits a definir qué es computable
* Formalismos y abstracciones (lógica y matemática)
* Técnicas algorítmicas
* ...

#
#### Ejemplo

Grafo

<img src='grafo.png' style='width: 50%'/>

<!--
#
#### Ejemplo

Grafo Dirigido

<img src='digrafo.png' style='width: 50%'/>

#
#### Ejemplo

Grafo con Pesos

<img src='grafo_pesado.png' style='width: 50%'/>
-->

#
#### Ejemplo

Camino mínimo

<img src='camino_minimo_pre.png' style='width: 50%'/>

#
#### Ejemplo

Camino mínimo

<img src='camino_minimo.png' style='width: 50%'/>

#
#### Ejemplo

_¿Como llego de mi casa al trabajo rápido?_

<img src='mapa.png' />

#
#### Ejemplo

_¿Como llego de mi casa al trabajo rápido?_

<img src='mapa_grafo.png' />

#
## Computación

* Programación 
* Análisis de problemas 
* Técnicas de resolución de problemas: abstraer y modularizar
* Full stack (de bits a definir qué es computable) 
* Formalismos y abstracciones (lógica y matemática)
* Técnicas algorítmicas 

#
## Computación

* <span style="opacity: 0.4"> Programación </span>
* <span style="opacity: 0.4"> Análisis de problemas </span>
* Técnicas de resolución de problemas: abstraer y modularizar
* <span style="opacity: 0.4"> Full stack (de bits a definir qué es computable) </span>
* Formalismos y abstracciones (lógica y matemática)
* <span style="opacity: 0.4"> Técnicas algorítmicas </span>

<!-- 
# El título ¿con qué se come? 
-->
 
# Programación e industria. Investigación y academia.

# 
## ¿Qué significa programar para vivir? 

#
* Resolver problemas en código
* Si te gusta, es divertido
* Mucha oferta
* Variedad de problemas
* Comodidades
* Suele ser poco repetitivo, se aprende todo el tiempo

#
#### Los problemas, a veces:

### Son teóricos

#
_¿Cómo detecto vuelos con precios irregulares?_

![](vuelos/vuelos.png)

#
_¿Cómo detecto vuelos con precios irregulares?_

![](vuelos/vuelos2.png)

<!--
#
_¿Cómo descarto vuelos que nadie compraría?_

* BUE-MIA, 10hs, $10000
* BUE-MIA, 8hs, $15000
* BUE-MIA, 12hs, $15000
* BUE-MIA, 12hs, $17000
-->

#
#### Los problemas, a veces:

### Son técnicos 

- ¿Cómo se configura la base de datos para funcionar en mi computadora?
- ¿Qué funcionalidades del lenguaje de programación me permiten 
  resolver mi problema?

#
#### Los problemas, a veces:

### Son humanos 

- ¿Cómo hago que mi código lo pueda modificar alguien más?
- ¿Qué tipo de búsquedas es esperable que haga un usuario?

#
## ¿Qué significa hacer ciencia? 

_Avanzar las fronteras del conocimiento_

* Si hay un problema, plantear una solución.
* Si hay una pregunta, plantear una respuesta.

. . .

Con rigor.

#
### En Computación

* Proponer un nuevo lenguaje de programacion, por ejemplo con fines
  educativos.
* Proponer una nueva tecnica en reconocimientos en objetos en imagenes.
* Demostrar que el algoritmo X resuelve correctamente ciertos casos de un
  problema.

#
## Interdisciplina

_La computación como herramienta_

#
### Para obtener datos

_¿Se usan distintas palabras según la región del país?_

<img src='twitter-feed.png'/>

<!--

#
### Para obtener datos

<img src='codigo-twitter.png' style='width: 120%'/>

#
### Para obtener datos
<img src='twitter-result.png'/>

#
### Para analizar datos

_¿Cambia la entonación cuando hacemos preguntas?_

`2 audios con f0`
`Código que extrae y calcula promedio`

-->

#
### Para modelar

<div style="height:500px">
<iframe src="Segregation.html" style='zoom:120%; height:100%; width:100%'></iframe>
</div>

# Fin

#### ¡Gracias!

#
### Extras

* [Mi investigación](#mi_inv)
* [Laburar afuera](#afuera)
* [Bio](#bio)
* [Inteligencia Artificial](#ia)

# Mi investigación {#mi_inv}

# {#afuera}
### ¿Laburar afuera, o para afuera? 

* Pasantías
* Mudarse
* Google, Facebook, Amazon, Microsoft, Olx, Spotify
* Trabajar para afuera


# Bio {#bio}

#

* 2007: Quiero hacer jueguitos (Aventuras gráficas), decido estudiar en Exactas
* 2008: CBC, Curso Java, App de celular para triangular matrices 

#

![](nokias.jpg)

#

* 2009: Inicio carrera, laburo apps BlackBerry
* 2010: Ay2, Cs. de la Computación
* 2012: Despegar.com, Java para web
* 2014: Pasantía Google
* 2015: MateMarote, Java para web + Js para juegos -- Licenciado

#

* 2016: Avenida.com, "Data Scientist"
* 2016: Inicio Doctorado, "Modelos de cognicion musical y patrones en el
  tiempo"
* 2017: JTP, Cs. de la Computación
* 2019: Programo jueguito para la materia

#

<video src="video-demo.mp4" style="width: 80%" controls/>

# ¿E inteligencia artificial? {#ia}

#
### Que la compu resuelva cosas "humanas"

* Reconocer caras
* Entender palabras en un audio 
* Responder preguntas
* Hacer demostraciones matemáticas
* Reconocer objetos en una imagen
* Manejar un auto

#
### Machine Learning

<img src="ml/ml1.png" style="width: 55%"/>

#
<img src="ml/ml2.png" style="width: 60%"/>

#
<img src="ml/ml3.png" style="width: 60%"/>


